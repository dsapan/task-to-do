from django.apps import AppConfig


class TaskToDoappConfig(AppConfig):
    name = 'task_to_doapp'
